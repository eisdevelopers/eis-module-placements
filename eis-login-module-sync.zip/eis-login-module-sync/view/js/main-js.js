/* 
 *  Project    : EIS Subscription Module
 *  EAO IT Services Pvt. Ltd. | www.eaoservices.com
 *  Copyright reserved @2017
 
 *  File Description :
 *  Main Javascipt file for the module
 
 *  Created on : 1 Aug, 2017 | 10:22:09 PM
 *  Author     : Bilal Wani
 *  Email      : bilal.wani@eaoservices
 
 */

$(document).ready(function(){    
    var div_subscriber_id = "#eis-subscribe-screen";
    $(div_subscriber_id).animate({top:'60px'},"slow");
    $(div_subscriber_id).slideDown(2000);;
});



